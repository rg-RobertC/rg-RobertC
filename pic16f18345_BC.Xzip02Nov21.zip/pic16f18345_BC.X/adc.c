// inc
//-------------------------------------------------------------------------
#include <xc.h>
#include "config.h"
#include "mcc_generated_files/mcc.h"
#include "txt.h"
#include "task.h"
#include "adc.h"


// param
//-------------------------------------------------------------------------
#define ADC_ACTIVE_MAX     21


// typedef
//-------------------------------------------------------------------------
typedef struct {
   uint_t   sta;
   uint_t   idx;
   u16      val;
   u8       str   [16];
} ADC_ARG_t;

typedef enum {
   ADC_CH_ANA0   = 0,
   ADC_CH_ANA1   = 1,
   ADC_CH_ANA2   = 2,
   ADC_CH_ANA4   = 4,
   ADC_CH_ANA5   = 5,
   ADC_CH_ANB4   = 12,
   ADC_CH_ANB5   = 13,
   ADC_CH_ANB6   = 14,
   ADC_CH_ANB7   = 15,
   ADC_CH_ANC0   = 16,
   ADC_CH_ANC1   = 17,
   ADC_CH_ANC2   = 18,
   ADC_CH_ANC3   = 19,
   ADC_CH_ANC4   = 20,
   ADC_CH_ANC5   = 21,
   ADC_CH_ANC6   = 22,
   ADC_CH_ANC7   = 23,
   ADC_CH_Vss    = 60,
   ADC_CH_Temp   = 61,
   ADC_CH_DAC1   = 62,
   ADC_CH_FVR    = 63,
} ADC_CH_t;


// var
//-------------------------------------------------------------------------
#ifdef DEBUG_ADC
   ADC_CH_t adcChList [ADC_ACTIVE_MAX] = {
      ADC_CH_ANA0, ADC_CH_ANA1, ADC_CH_ANA2, ADC_CH_ANA4,
      ADC_CH_ANA5, ADC_CH_ANB4, ADC_CH_ANB5, ADC_CH_ANB6, 
      ADC_CH_ANB7, ADC_CH_ANC0, ADC_CH_ANC1, ADC_CH_ANC2, 
      ADC_CH_ANC3, ADC_CH_ANC4, ADC_CH_ANC5, ADC_CH_ANC6, 
      ADC_CH_ANC7, ADC_CH_Vss,  ADC_CH_Temp, ADC_CH_DAC1, 
      ADC_CH_FVR   
   };
   
   static ADC_ARG_t   adcArg;
#endif


// proto
//-------------------------------------------------------------------------
/*
void ADC_Init (void);
void ADC_sel (uint_t ch);
void ADC_start (void);
bool ADC_get (u16 *pData);
*/
#ifdef DEBUG_ADC
   static bool ADC_Debug_Task (void *pvArg);
#endif


//-------------------------------------------------------------------------
void ADC_Init (void) {
//-------------------------------------------------------------------------
   // setup adc 
   ADCON1 = 0xF0;       // rc oscillator, vref+ = Vdd, vref- = Vss
                        // data right justified
   ADCON0 = 0x01;
   #ifdef DEBUG_ADC
      // start adc debug task
      adcArg.sta = 0;
      TASK_Add (ADC_Debug_Task, &adcArg);
   #endif
}

//-------------------------------------------------------------------------
void ADC_sel (uint_t ch) {
//-------------------------------------------------------------------------
   ADCON0bits.CHS       = ch;          // select channel
   ADCON0bits.ADON      = 1;           // enable adc
   NOP();
   NOP();
}

//-------------------------------------------------------------------------
void ADC_start (void) {
//-------------------------------------------------------------------------
   ADCON0bits.ADGO      = 1;           // start conversion
}

//-------------------------------------------------------------------------
bool ADC_get (u16 *pData) {
//-------------------------------------------------------------------------  
   // check conversion data ready
   if (ADCON0bits.ADGO == 1) return false;
   // assign adc data to pointer 
   *pData = (((u16)(ADRESH & 0x3))<<8) | ADRESL;
   // disable adc
   ADCON0bits.ADON = 0;
   return true;
}

#ifdef DEBUG_ADC
//-------------------------------------------------------------------------
static bool ADC_Debug_Task (void *pvArg) {
//-------------------------------------------------------------------------
   ADC_ARG_t  *pArg = (ADC_ARG_t *)pvArg;
   bool        done = false;
   uint_t      len;
   
   switch (TASK_STATE) {
      case 0:
         // initialize starting channel index
         pArg->idx = 0;
         // enable temperature sensor
         FVRCONbits.TSEN = 1;
         FVRCONbits.TSRNG = 1;
         // exit initialization
         TASK_STATE = 1;
         break;
      
      case 1:
         // start adc sample
         ADC_sel (adcChList[pArg->idx]);      
         // print adc channel
         UART_Send (5, (u8 *)"ADC, ");
         len = TXT_u8toAscii_Dec ((u8)adcChList[pArg->idx], pArg->str);
         UART_Send (len, pArg->str);
         UART_Send (2, (u8 *)", ");
         // sleep 10ms
         TASK_Sleep (10);
         // next state
         TASK_STATE = 2;
         break;
         
      case 2:
         ADC_start ();
         TASK_STATE = 3;
         break;
      
      case 3:
         // check if conversion done
         if (ADC_get (&pArg->val) == false) break;
         // print adc channel sample
         len = TXT_u16toAscii_Dec (pArg->val, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send (2, (u8 *)"\n\r");
         // advance channel
         pArg->idx = (pArg->idx+1) % ADC_ACTIVE_MAX;
         // sleep 990ms
         TASK_Sleep (990);
         // next state
         TASK_STATE = 1;
         break;
      
      default:
         done = true;
   }
   
   return done;
}
#endif   // DEBUG_ADC

#ifndef _SYS_H_
#define _SYS_H_


// extern
//-------------------------------------------------------------------------
extern void SYS_Init (void);


#endif

// inc
//-------------------------------------------------------------------------
#include "txt.h"


// const
//-------------------------------------------------------------------------
static const u8    strNumTbl   [] = "0123456789abcdefghij";


// proto
//-------------------------------------------------------------------------
/*
uint_t  TXT_u8toAscii_Dec (u8 val, u8 *pStr);
uint_t  TXT_u16toAscii_Dec (u16 val, u8 *pStr);
uint_t  TXT_u32toAscii_Dec (u32 val, u8 *pStr);
uint_t  TXT_u8toAscii_Hex (u8 val, u8 *pStr);
uint_t  TXT_u16toAscii_Hex (u16 val, u8 *pStr);
uint_t  TXT_u32toAscii_Hex (u32 val, u8 *pStr);
*/

//-------------------------------------------------------------------------
uint_t TXT_u8toAscii_Dec (u8 val, u8 *pStr) {
//-------------------------------------------------------------------------
   uint_t idx, len;

   // validate pointer parameter
   if (pStr == NULL) return 0;

   // determine number of digits in string
   if (val < 10)
      idx = 1;
   else if (val < 100)
      idx = 2;
   else 
      idx = 3;

   // set return length
   len = idx;

   while (idx > 0) {
      uint_t i = val % 10;
      val /= 10;
      idx--;
      pStr[idx] = strNumTbl[i];
   }

   return len;
}

//-------------------------------------------------------------------------
uint_t TXT_u16toAscii_Dec (u16 val, u8 *pStr) {
//-------------------------------------------------------------------------
   uint_t idx, len;

   // validate pointer parameter
   if (pStr == NULL) return 0;

   // determine number of digits in string
   if (val < 10)
      idx = 1;
   else if (val < 100)
      idx = 2;
   else if (val < 1000)
      idx = 3;
   else if (val < 10000)
      idx = 4;
   else
      idx = 5;

   // set return length
   len = idx;

   while (idx > 0) {
      uint_t i = val % 10;
      val /= 10;
      idx--;
      pStr[idx] = strNumTbl[i];
   }

   return len;
}

//-------------------------------------------------------------------------
uint_t TXT_u32toAscii_Dec (u32 val, u8 *pStr) {
//-------------------------------------------------------------------------
   uint_t idx, len;

   // validate pointer parameter
   if (pStr == NULL) return 0;

   // determine number of digits in string
   if (val < 10)
      idx = 1;
   else if (val < 100)
      idx = 2;
   else if (val < 1000)
      idx = 3;
   else if (val < 10000)
      idx = 4;
   else if (val < 100000)
      idx = 5;
   else if (val < 1000000)
      idx = 6;
   else if (val < 10000000)
      idx = 7;
   else if (val < 100000000)
      idx = 8;
   else if (val < 1000000000)
      idx = 9;
   else
      idx = 10;

   // set return length
   len = idx;

   while (idx > 0) {
      uint_t i = val % 10;
      val /= 10;
      idx--;
      pStr[idx] = strNumTbl[i];
   }

   return len;
}

//-------------------------------------------------------------------------
uint_t TXT_u8toAscii_Hex (u8 val, u8 *pStr) {
//-------------------------------------------------------------------------
   // validate pointer parameter
   if (pStr == NULL) return 0;
   pStr[1] = strNumTbl[ val      & 0xf];
   pStr[0] = strNumTbl[(val>>4 ) & 0xf];
   return 2;
}

//-------------------------------------------------------------------------
uint_t TXT_u16toAscii_Hex (u16 val, u8 *pStr) {
//-------------------------------------------------------------------------
   // validate pointer parameter
   if (pStr == NULL) return 0;
   pStr[3] = strNumTbl[ val      & 0xf];
   pStr[2] = strNumTbl[(val>>4 ) & 0xf];
   pStr[1] = strNumTbl[(val>>8 ) & 0xf];
   pStr[0] = strNumTbl[(val>>12) & 0xf];
   return 4;
}

//-------------------------------------------------------------------------
uint_t TXT_u32toAscii_Hex (u32 val, u8 *pStr) {
//-------------------------------------------------------------------------
   // validate pointer parameter
   if (pStr == NULL) return 0;
   pStr[7] = strNumTbl[ val      & 0xf];
   pStr[6] = strNumTbl[(val>>4 ) & 0xf];
   pStr[5] = strNumTbl[(val>>8 ) & 0xf];
   pStr[4] = strNumTbl[(val>>12) & 0xf];
   pStr[3] = strNumTbl[(val>>16) & 0xf];
   pStr[2] = strNumTbl[(val>>20) & 0xf];
   pStr[1] = strNumTbl[(val>>24) & 0xf];
   pStr[0] = strNumTbl[(val>>28) & 0xf];
   return 8;
}

#ifndef _MAIN_
#define _MAIN_


// inc
//-------------------------------------------------------------------------
#include <stddef.h>                     // Defines NULL
#include <stdbool.h>                    // Defines true/false
#include <stdlib.h>                     // Defines EXIT_FAILURE
#include <stdint.h>


// param
//-------------------------------------------------------------------------
#define FOSC_FREQ             16000000UL


// type
//-------------------------------------------------------------------------
typedef uint8_t         u8      ;   
typedef int8_t          s8      ;   
typedef uint16_t        u16     ;   
typedef int16_t         s16     ;   
typedef uint32_t        u32     ;   
typedef int32_t         s32     ;
typedef float           f32     ;

typedef uint8_t         uint_t  ;      // native type
typedef int8_t          int_t   ;      // native type      


// type
//-------------------------------------------------------------------------
typedef union {
   void       *pv;
   int8_t      s8;
   int8_t      s8a      [4];
   uint8_t     u8;
   uint8_t     u8a      [4];
   int16_t     s16;
   int16_t     s16a     [2];
   uint16_t    u16;
   uint16_t    u16a     [2];
   int32_t     s32;
   uint32_t    u32;
   uint8_t     uint;
} utyp_t;
   
typedef union {
   void       *pv;
   uint8_t    *pu8;
   int8_t     *ps8;
   uint16_t   *pu16;
   int16_t    *ps16;
   uint32_t   *pu32;
   int32_t    *ps32;
} uptr_t;


#endif

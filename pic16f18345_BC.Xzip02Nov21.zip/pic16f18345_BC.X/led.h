#ifndef _LED_H_
#define _LED_H_


// inc
//-------------------------------------------------------------------------
#include "main.h"


// macro
//-------------------------------------------------------------------------
#define LED_LO    0
#define LED_HI    5000   //BC update to 50000 ? so ON Longer nope reset to 5000
#define LED_1Hz   500
#define LED_2Hz   250
#define LED_4Hz   125


// extern
//-------------------------------------------------------------------------
extern void LED_Init (void);
extern void LED_set (u16 period);

#endif
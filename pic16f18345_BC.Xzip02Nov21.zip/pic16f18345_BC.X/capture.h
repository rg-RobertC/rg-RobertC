#ifndef _CAPTURE_H_
#define _CAPTURE_H_


// inc
//-------------------------------------------------------------------------
#include "main.h"


// extern
//-------------------------------------------------------------------------
extern void TMR1_ISR (void);
extern void CCP1_ISR (void);
extern void CCP2_ISR (void);
extern void CAP_Init (void);
extern void CAP_get (u16 *pData1, u16 *pData2);

#endif

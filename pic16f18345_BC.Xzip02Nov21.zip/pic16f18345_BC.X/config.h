#ifndef _CONFIG_H_
#define _CONFIG_H_


//#define CRC_GEN
//#define ENABLE_NCO
//#define DEBUG_PWM
//#define DEBUG_ADC
#define DEBUG_RES


#endif

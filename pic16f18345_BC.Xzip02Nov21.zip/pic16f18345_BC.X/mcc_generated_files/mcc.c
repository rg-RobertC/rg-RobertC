// inc
//-------------------------------------------------------------------------
#include "mcc.h"


//-------------------------------------------------------------------------
void SYSTEM_Initialize (void) {
   PMD_Initialize();
   PIN_MANAGER_Initialize();
   OSCILLATOR_Initialize();
   WDT_Initialize();
   TMR2_Initialize();
   PWM3_Initialize();
   NCO1_Initialize();
   UART_Initialize ();
}

//-------------------------------------------------------------------------
void OSCILLATOR_Initialize (void) {
//-------------------------------------------------------------------------
   // NOSC HFINTOSC; NDIV 2;
   OSCCON1 = 0x61;
   // CSWHOLD may proceed; SOSCPWR Low power; SOSCBE crystal oscillator;
   OSCCON3 = 0x00;
   // LFOEN disabled; ADOEN disabled; SOSCEN disabled; EXTOEN disabled; HFOEN disabled;
   OSCEN = 0x00;
   // HFFRQ 32_MHz;
   OSCFRQ = 0x07;
   // HFTUN 0;
   OSCTUNE = 0x00;
}

//-------------------------------------------------------------------------
void WDT_Initialize(void) {
//-------------------------------------------------------------------------
   // WDTPS 1:65536; SWDTEN OFF;
   WDTCON = 0x16;
}

//-------------------------------------------------------------------------
void PMD_Initialize(void) {
//-------------------------------------------------------------------------
   // CLKRMD CLKR enabled; SYSCMD SYSCLK enabled; FVRMD FVR enabled; IOCMD IOC enabled; NVMMD NVM enabled;
   PMD0 = 0x00;
   // TMR0MD TMR0 enabled; TMR1MD TMR1 enabled; TMR4MD TMR4 enabled; TMR5MD TMR5 enabled; TMR2MD TMR2 enabled; TMR3MD TMR3 enabled; NCOMD DDS(NCO) enabled; TMR6MD TMR6 enabled;
   PMD1 = 0x00;
   // DACMD DAC enabled; CMP1MD CMP1 enabled; ADCMD ADC enabled; CMP2MD CMP2 enabled;
   PMD2 = 0x00;
   // CCP2MD CCP2 enabled; CCP1MD CCP1 enabled; CCP4MD CCP4 enabled; CCP3MD CCP3 enabled; PWM6MD PWM6 enabled; PWM5MD PWM5 enabled; CWG2MD CWG2 enabled; CWG1MD CWG1 enabled;
   PMD3 = 0x00;
   // MSSP1MD MSSP1 enabled; UART1MD EUSART enabled; MSSP2MD MSSP2 enabled;
   PMD4 = 0x00;
   // DSMMD DSM enabled; CLC3MD CLC3 enabled; CLC4MD CLC4 enabled; CLC1MD CLC1 enabled; CLC2MD CLC2 enabled;
   PMD5 = 0x00;
}

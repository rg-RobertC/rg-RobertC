/**
   NCO1 Generated Driver File
 
   @Company
     Microchip Technology Inc.
 
   @File Name
     nco1.c
 
   @Summary
     This is the generated driver implementation file for the NCO1 driver using PIC10 / PIC12 / PIC16 / PIC18 MCUs
 
   @Description
     This source file provides implementations for driver APIs for NCO1.
     Generation Information :
         Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.81.6
         Device            :  PIC16F18345
         Driver Version    :  2.11
     The generated drivers are tested against the following:
         Compiler          :  XC8 2.30 and above or later
         MPLAB             :  MPLAB X 5.40
 */ 

 /*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/
 
 /**
   Section: Included Files
 */

#include <xc.h>
#include "nco1.h"

/**
  Section: NCO Module APIs
*/

// param
//-------------------------------------------------------------------------
#define NCO_CLK_FREQ       8000000UL


//-------------------------------------------------------------------------
void NCO1_Initialize (void) {
//-------------------------------------------------------------------------
   // Set the NCO to the options selected in the GUI
   // N1EN disabled; N1POL active_hi; N1PFM PFM_mode; 
   NCO1CON = 0x01;
   // N1PWS 16_clk; N1CKS FOSC;
   NCO1CLK = 0x81;
   // 
   NCO1ACCU = 0x00;
   // 
   NCO1ACCH = 0x00;
   // 
   NCO1ACCL = 0x00;
   // 
   NCO1INCU = 0x00;
   // 
   NCO1INCH = 0x33;
   // 
   NCO1INCL = 0x33;
   
   // Enable the NCO module
   NCO1CONbits.N1EN = 1;
}

//-------------------------------------------------------------------------
bool NCO1_GetOutputStatus(void) {
//-------------------------------------------------------------------------
   // Return output status on accumulator over flow
   return (NCO1CONbits.N1OUT);
}

//-------------------------------------------------------------------------
void NCO1_Incr_set (uint32_t incVal) {
//-------------------------------------------------------------------------
   union {
      uint32_t u32;
      uint8_t  u8    [4];
   } val;
   
   val.u32 = incVal;
   
   // update increment value, must be in exact order from high to low. 
   // last value updates all registers at the same time because of register 
   // double buffering.
   NCO1INCU = val.u8[2] & 0xF;
   NCO1INCH = val.u8[1];
   NCO1INCL = val.u8[0];
}

//-------------------------------------------------------------------------
void NCO1_Freq_set (uint32_t freqVal) {
//-------------------------------------------------------------------------
   // assume FOSC = 16 MHz, pulse frequency mode
   // if requested frequency greater than max frequency, force max
   if (freqVal > 240000) freqVal = 240000;
   // calculate increment value
   uint32_t incVal = (freqVal<<10);
   incVal /= (NCO_CLK_FREQ >> 9);
   // set increment register
   NCO1_Incr_set (incVal);
}

// inc
//-------------------------------------------------------------------------
#include "xc.h"
#include "uart.h"


// param
//-------------------------------------------------------------------------
#define BAUDRATE              38400UL
#define UART_RX_BUFFER_SIZE   (1<<5)
#define UART_TX_BUFFER_SIZE   (1<<6)
#define UART_TX_PKT_DEPTH     (1<<4)


// type
//-------------------------------------------------------------------------
typedef struct {
   uint_t   hd;
   uint_t   tl;
   u8       da    [UART_RX_BUFFER_SIZE];
} UART_RX_t;

typedef struct {
   uint_t   len;
   u8      *pDa;
} UART_PKT_t;

typedef struct {
   uint_t      hd;
   uint_t      tl;
   UART_PKT_t  pkt   [UART_TX_PKT_DEPTH];
} UART_PKTS_t;

typedef enum {
   TX_STA_CheckQueue,
   TX_STA_Sending
} TX_STA_t;


// var
//-------------------------------------------------------------------------
static UART_RX_t rxStream = {
   .hd   = 0,
   .tl   = 0};
   
static UART_PKTS_t txPkts = {
   .hd   = 0,
   .tl   = 0};

static TX_STA_t txSta = TX_STA_CheckQueue;


// proto
//-------------------------------------------------------------------------
/*
void  UART_Initialize (void);
void  UART_Receive_ISR (void);
u8   *UART_Receive (uint_t *pLen, u8 *pDa);
void  UART_Transmit_ISR (void);
bool  UART_Send (uint_t len, u8 *pDa);
bool  UART_Send_str (u8 *pStr, u8 endCh);
*/

//-------------------------------------------------------------------------
void UART_Receive_ISR (void) {
//-------------------------------------------------------------------------
   // read receiver character, clear receive interrupt
   u8 tmp = RC1REG;
   
   //if (RC1STAbits.FERR) {};
   
   // UART error - restart
   if (RC1STAbits.OERR) {
      RC1STAbits.CREN = 0;
      RC1STAbits.CREN = 1;
   }
   else {
      // check buffer isn't full
      uint_t next = (rxStream.hd + 1) % UART_RX_BUFFER_SIZE;
      if (next == rxStream.tl) return;
      // copy to receive character stream
      rxStream.da[rxStream.hd] = tmp;
      // advance head index
      rxStream.hd = next;
   }
}

//-------------------------------------------------------------------------
void UART_Transmit_ISR (void) {
//-------------------------------------------------------------------------
   static UART_PKT_t *pPkt;
   
   switch (txSta) {
      case TX_STA_CheckQueue:
         // check send queue
         if (txPkts.hd == txPkts.tl) {
            // disable transmit interrupt
            PIE1bits.TXIE = 0;
            break;
         }
         // set pkt pointer, next state
         pPkt = &(txPkts.pkt[txPkts.tl]);
         txSta = TX_STA_Sending;
         
      case TX_STA_Sending:
         // send data, decrement length
         TX1REG = *(pPkt->pDa++);
         pPkt->len--;
         // check complete packet sent
         if (pPkt->len > 0) break;
         // advance tail index, go back to queue checking
         txPkts.tl = (txPkts.tl + 1) % UART_TX_PKT_DEPTH;
         txSta = TX_STA_CheckQueue;
         break;
      
      default:
         // disable transmit interrupt
         PIE1bits.TXIE = 0;
         txSta = TX_STA_CheckQueue;
   }
}

//-------------------------------------------------------------------------
void UART_Initialize (void) {
//-------------------------------------------------------------------------
   utyp_t   period;
   
   // set starting task state
   txSta = TX_STA_CheckQueue;
   
   // disable interrupts before changing states
   PIE1bits.RCIE = 0;
   PIE1bits.TXIE = 0;

   BAUD1CON = 0;
   BAUD1CONbits.ABDEN   = 0;     // disabled autobaud detection
   BAUD1CONbits.WUE     = 0;     // disabled wakeup
   BAUD1CONbits.BRG16   = 0;     // baudrate generator 8-bit mode
   BAUD1CONbits.SCKP    = 0;     // transmit idle state - high

   RC1STA = 0;
   RC1STAbits.ADDEN     = 0;     // address detection disabled (9-bit mode only)
   RC1STAbits.CREN      = 1;     // enable continuous receive
   RC1STAbits.SREN      = 0;     // disable single receive
   RC1STAbits.RX9       = 0;     // 8-bit mode
   RC1STAbits.SPEN      = 1;     // enable serial port
   
   TX1STA = 0;
   TX1STAbits.BRGH      = 1;     // low speed (async mode)
   TX1STAbits.SENDB     = 0;     // disable send break
   TX1STAbits.SYNC      = 0;     // asynchronous mode
   TX1STAbits.TX9       = 0;     // 8-bit mode
   TX1STAbits.TXEN      = 1;     // enable transmitter

   // set baudrate
   period.u32 = (FOSC_FREQ / (u32)(BAUDRATE*16)) - 1;
   SP1BRGL = period.u8a[0];
   SP1BRGH = period.u8a[1];
   
   // enable receive interrupt
   PIE1bits.RCIE = 1;
}

//-------------------------------------------------------------------------
u8 *UART_Receive (uint_t *pLen, u8 *pDa) {
//-------------------------------------------------------------------------
   uint_t next;
   
   // validate pointers
   if (pLen == NULL || pDa == NULL) return NULL;
   // read receive stream
   while (rxStream.hd != rxStream.tl && (*pLen) > 0) {
      // read value to pointer, decrement counter
      *(pDa++) = rxStream.da[rxStream.tl];
      (*pLen)--;
      // advance stream tail
      rxStream.tl = (rxStream.tl + 1) % UART_RX_BUFFER_SIZE;
   }
   // return last pointer location
   return pDa;
}

//-------------------------------------------------------------------------
bool UART_Send (uint_t len, u8 *pDa) {
//-------------------------------------------------------------------------
   UART_PKT_t *pPkt;
   uint_t      next;
   
   // validate pointer, length
   if (pDa == NULL  || len == 0) return false;
   if (len > 64) len = 64;
   // assign next head for queue full checking
   next = (txPkts.hd + 1) % UART_TX_PKT_DEPTH;
   // check for full transmit queue
   if (next == txPkts.tl) return false;
   // assign pointer, length
   pPkt = &(txPkts.pkt[txPkts.hd]);
   pPkt->pDa = pDa;
   pPkt->len = len;
   // update head index
   txPkts.hd = next;
   // enable transmit interrupt if not active
   if (PIE1bits.TXIE == 0) 
      PIE1bits.TXIE = 1;
   // successfully added transmit request to queue
   return true;
}

//-------------------------------------------------------------------------
bool UART_Send_str (u8 *pStr, u8 endCh) {
//-------------------------------------------------------------------------
   UART_PKT_t *pPkt;
   uint_t      next;
   u8         *pDa;
   uint_t      len;
   
   // validate pointer
   if (pDa == NULL) return false;
      
   // determine string length
   for (len = 0, pDa = pStr; *pDa != endCh; len++, pDa++) {
      if (len > 64) break;
   }
   
   // exit if length of string is 0
   if (len == 0) return true;
   
   // assign next head for queue full checking
   next = (txPkts.hd + 1) % UART_TX_PKT_DEPTH;
   // check for full transmit queue
   if (next == txPkts.tl) return false;
   // assign pointer, length
   pPkt = &(txPkts.pkt[txPkts.hd]);
   pPkt->pDa = pStr;
   pPkt->len = len;
   // update head index
   txPkts.hd = next;
   // enable transmit interrupt if not active
   if (PIE1bits.TXIE == 0) 
      PIE1bits.TXIE = 1;
   // successfully added transmit request to queue
   return true;
   
}


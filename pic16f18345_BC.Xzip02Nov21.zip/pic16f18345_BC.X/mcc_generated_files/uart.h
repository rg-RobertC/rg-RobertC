#ifndef _UART_H_
#define _UART_H_


// inc
//-------------------------------------------------------------------------
#include "..\main.h"


// extern
//-------------------------------------------------------------------------
extern void UART_Initialize (void);
extern void UART_Receive_ISR (void);
extern u8  *UART_Receive (uint_t *pLen, u8 *pDa);
extern void UART_Transmit_ISR (void);
extern bool UART_Send (uint_t len, u8 *pDa);
extern bool UART_Send_str (u8 *pStr, u8 endCh);

#endif

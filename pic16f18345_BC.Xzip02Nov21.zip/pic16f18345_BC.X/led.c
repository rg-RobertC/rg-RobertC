// inc
//-------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
#include "task.h"
#include "led.h"


// var
//-------------------------------------------------------------------------
static u16  ledPeriod;


// proto
//-------------------------------------------------------------------------
/*
void        LED_Init (void);
void        LED_set (u16 period);
*/
static bool LED_Task (void *pvArg);


//-------------------------------------------------------------------------
void LED_Init (void) {
//-------------------------------------------------------------------------
   ledPeriod = 5000;    //BC set from 0 to 5000 = Led set high = LED OFF?
   TASK_Add (LED_Task, NULL);
}

//-------------------------------------------------------------------------
void LED_set (u16 period) {
//-------------------------------------------------------------------------
   // start 2Hz blink task
   ledPeriod = period;
}
            
//-------------------------------------------------------------------------
static bool LED_Task (void *pvArg) {
//-------------------------------------------------------------------------
   if (ledPeriod < 50) {
      LED_SetLow();  //BC LED line LOW = LED ON ?
      TASK_Sleep (500);
   }
   else if (ledPeriod > 2000) {
      LED_SetHigh();  //BC LED line High = LED OFF ?
      TASK_Sleep (500);
   }
   else {
      LED_Toggle();
      TASK_Sleep (ledPeriod);
   }
   
   return false;
}
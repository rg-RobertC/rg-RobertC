// inc
//-------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
#include "config.h"
#include "task.h"
#include "sys.h"


//-------------------------------------------------------------------------
void main(void) {
//-------------------------------------------------------------------------
   // initialize the device
   SYSTEM_Initialize();

   // initialize kernel
   TASK_Init();

   // start system task
   SYS_Init();

   // start task scheduler
   TASK_Scheduler ();
}

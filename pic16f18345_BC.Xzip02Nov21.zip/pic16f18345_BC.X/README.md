# pic16f18345
 
Build tools
---------------------------------------------------------------------------
IDE      :  MPLAB X IDE v5.40 (free)
Compiler :  XC8 v2.31 (free)


Build Procedure
---------------------------------------------------------------------------
1.  Ensure IDE/Compiler installed
2.  Start MPLAB X IDE
3.  Select File->Open Project menu item
4.  "Open Project" dialog opens
5.  Navigate to top level folder where project folder is located
6.  Select the project folder, click "Open Project" button
7.  Select Production->Build Main Project menu item


Output 
---------------------------------------------------------------------------
Location :  pic16f18345\dist\default\production
Name     :  pic16f18345.production.hex

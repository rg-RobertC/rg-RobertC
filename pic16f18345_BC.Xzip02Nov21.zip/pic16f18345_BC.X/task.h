#ifndef _TASK_H_
#define _TASK_H_


// inc
//-------------------------------------------------------------------------
#include "main.h"


// macro
//-------------------------------------------------------------------------
#define  TASK_STATE     pArg->sta


// extern
//-------------------------------------------------------------------------
extern void    TMR0_ISR (void);
extern void    TASK_Init (void);
extern uint_t  TASK_Add (bool (*pTask)(void *), void *pvArg);
extern void    TASK_Sleep (u16 period);
extern bool    TASK_Wake (uint_t handle);
extern void    TASK_Kill (uint_t *pHandle);
extern void    TASK_Scheduler (void);

#endif

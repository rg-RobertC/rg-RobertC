// inc
//-------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
#include "config.h"
#include "led.h"
#include "txt.h"
#include "crc.h"
#include "task.h"
#include "capture.h"
#include "adc.h"
#include "sys.h"


// param
//-------------------------------------------------------------------------
#define CFG_BASE_ADDR            0x7000
#define CRC_POLY                 0x1021
#define PWM_STEP_SIZE           (1<<5)
#define CAPTURE_FACTOR           8
#define CAL_ITERATIONS           4
#define CAL_MULTIPLIER          (CAPTURE_FACTOR / CAL_ITERATIONS)
#define REF_BAND                 1000     // reference band  (Hz)

// macro
//-------------------------------------------------------------------------
#define RES_set(x)               LATC = x


// const
//-------------------------------------------------------------------------
const u8    strSysInfo     [] = "PIC 16F18345 Demonstrator - v0.37";
const u8    strCrLf        [] = "\n\r";
const u8    strCommaSpace  [] = ", ";


// type
//-------------------------------------------------------------------------
typedef struct {
   uint_t   sta;
   u16      cnt;
   u16      addr;
   u8      *pChar;
   utyp_t   measRef;
   utyp_t   measTst;
   utyp_t   resOut;
   u8       str      [8];
} SYS_ARG_t;

typedef union {
   u8    buf      [16];
   struct {
      u32      calRef;
      u32      calMin;
      u32      calMax;
      u8       spare    [2];
      u16      crc;
   };
} SYS_CFG_t;

typedef struct {
   uint_t   sta;
   u16      dc;
} PWM_ARG_t;

typedef struct {
   uint_t   sta;
   u32      freq;
   u32      step;
   u32      top;
   u32      bottom;
} NCO_ARG_t;

typedef struct {
   uint_t   sta;
   u16      cnt;
   u16      addr;
   u32      sum;
   u32      ref;
   u32      min;
   u32      max;
   u8      *pChar;
   #ifdef ENABLE_NCO
      uint_t  handle;
   #endif
   u8       str      [8];
} CAL_ARG_t;

#ifdef DEBUG_RES
   typedef struct {
      uint_t   sta;
      u8       val;
      u8       str      [12];
   } RES_ARG_t;
#endif


// var
//-------------------------------------------------------------------------
static SYS_CFG_t     sysCfg;

static CAL_ARG_t     calArg;
static SYS_ARG_t     sysArg;

static uint_t        calTaskHandle = (uint_t)(-1);

#ifdef DEBUG_PWM
   static PWM_ARG_t     pwm3Arg;
#endif

#ifdef ENABLE_NCO
   static NCO_ARG_t  ncoArg;
   static bool       NCO_Task (void *pvArg);
#endif

#ifdef DEBUG_RES
   static RES_ARG_t     resArg;
#endif


// proto
//-------------------------------------------------------------------------
/*
void           SYS_Init (void);
*/
static bool    CAL_Task (void *pvArg);
static bool    INPUT_get (uint_t val, u16 period, u16 *pCnt, u32 *pSum);
static void    RES_Init (void);
static void    SYS_Setup (void);
static bool    SYS_Config_Task (void *pvArg);
static bool    SYS_Task (void *pvArg);

#ifdef DEBUG_PWM
   static bool       PWM3_Test_Task (void *pvArg);
#endif

#ifdef DEBUG_RES
   static bool       RES_Test_Task (void *pvArg);
#endif


//-------------------------------------------------------------------------
void __interrupt() INTERRUPT_InterruptManager (void) {
//-------------------------------------------------------------------------
   if (PIR0bits.TMR0IF == 1)
      TMR0_ISR ();

   if (PIR1bits.TMR1IF == 1)
      TMR1_ISR ();

   if (PIR1bits.TXIF == 1)
      UART_Transmit_ISR ();

   if (PIE1bits.RCIE == 1 && PIR1bits.RCIF == 1)
      UART_Receive_ISR ();

   if (PIE4bits.CCP1IE == 1 && PIR4bits.CCP1IF == 1)
      CCP1_ISR();

   if (PIE4bits.CCP2IE == 1 && PIR4bits.CCP2IF == 1)
      CCP2_ISR();
}

//-------------------------------------------------------------------------
void SYS_Init (void) {
//-------------------------------------------------------------------------
   sysArg.sta = 0;
   TASK_Add (SYS_Config_Task, (void *)&sysArg);
}

//-------------------------------------------------------------------------
static bool SYS_Config_Task (void *pvArg) {
//-------------------------------------------------------------------------
   SYS_ARG_t  *pArg   = (SYS_ARG_t *)pvArg;
   bool        done   = false;
   utyp_t      tmp;
   uint_t      len;

   // read eeprom configuration setting.  if configuration values not
   // previously set, set default value.

   switch (TASK_STATE) {
      case 0:
         // wait 4 seconds
         TASK_Sleep (4000);
         // exit initialization
         TASK_STATE = 1;
         break;

      case 1:
         // print system info
         UART_Send_str ((u8 *)strSysInfo, 0);
         UART_Send_str ((u8 *)" - ", 0);
         UART_Send_str ((u8 *)__DATE__, 0);
         UART_Send_str ((u8 *)" - ", 0);
         UART_Send_str ((u8 *)__TIME__, 0);
         UART_Send_str ((u8 *)strCrLf, 0);
         // wait 1 second
         TASK_Sleep (1000);
         // next state
         TASK_STATE = 2;
         break;

      case 2:
         // clear configuration
         len = 16;
         pArg->pChar = sysCfg.buf;
         while (len--)
            *(pArg->pChar++) = 0;
         // set start address
         pArg->addr = CFG_BASE_ADDR;
         // set source pointer
         pArg->pChar = sysCfg.buf;
         // exit initialization
         TASK_STATE = 3;
         break;

      case 3:
         // read configuration from nonvolatile memory
         tmp.u8 = DATAEE_ReadByte (pArg->addr);
         *(pArg->pChar++) = tmp.u8;
         // print
         len = TXT_u8toAscii_Hex (tmp.u8, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send_str ((u8 *)strCommaSpace, 0);
         // increment eeprom address
         pArg->addr++;
         if (pArg->addr >= (CFG_BASE_ADDR + sizeof(SYS_CFG_t))) {
            // reset address
            pArg->addr = CFG_BASE_ADDR;
            // next state
            TASK_STATE = 4;
         }
         // wait 10ms
         TASK_Sleep (10);
         break;

      case 4:
         // print crc
         tmp.u16 = CRC_Calc (sysCfg.buf, 14);
         len = TXT_u16toAscii_Hex (tmp.u16, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send_str ((u8 *)strCrLf, 0);
         // wait 10ms
         TASK_Sleep (10);
         // next state
         TASK_STATE = (tmp.u16 == sysCfg.crc) ? 7 : 5;
         break;

      case 5:
         // set default configuration values if not previously set
         sysCfg.calRef     = 101000;
         sysCfg.calMin     = 78900;
         sysCfg.calMax     = 23456;
         sysCfg.spare[0]   = 0xde;
         sysCfg.spare[1]   = 0xad;
         sysCfg.crc        = CRC_Calc (sysCfg.buf, (sizeof(SYS_CFG_t)-sizeof(crc)));
         // set start address
         pArg->addr = CFG_BASE_ADDR;
         // set source pointer
         pArg->pChar = sysCfg.buf;
         // next state
         TASK_STATE = 6;

      case 6:
         // write byte
         DATAEE_WriteByte (pArg->addr, *(pArg->pChar++));
         // increment address
         pArg->addr++;
         if (pArg->addr < (CFG_BASE_ADDR + sizeof(SYS_CFG_t))) 
            break;
         // console indicator - newline
         UART_Send_str ((u8 *)strCrLf, 0);
         // wait 10ms
         TASK_Sleep (10);
         // next state
         TASK_STATE = 2; //BC should this be TASK 7 ????

      case 7:
         // setup system
         SYS_Setup ();

      default:
         done = true;
   }

   return done;
}

//-------------------------------------------------------------------------
static bool INPUT_get (uint_t val, u16 period, u16 *pCnt, u32 *pSum) {
//-------------------------------------------------------------------------
   bool flag = false;
   // wait for magnet to be removed
   if (RA1_GetValue() != val) //BC Has RA1 changed state? Loi indicated this had to go to high to trigger (but stay low for a specified period first? = 25? Does this simply detect that RA1 has gone low 
      (*pCnt) = 0;
   else if ((*pCnt) < 25)
      (*pCnt)++;
   else {
      // clear count, sum
      (*pCnt) = 0;
      (*pSum) = 0;
      // set blink period
      LED_set (LED_2Hz);  //BC should this "period" be = "LED_2Hz"? ie sets the LED Blinking "Im in Empty CAL mode". TRy LED_2Hz again but update following sequence
      // set flag
      flag = true;
   }
   // return input status 
   return flag;
}

//-------------------------------------------------------------------------
static bool CAL_Task (void *pvArg) {
//-------------------------------------------------------------------------
   CAL_ARG_t  *pArg = (CAL_ARG_t *)pvArg;
   bool        done = false;
   utyp_t      tmp;
   u16         refProbe, tstProbe;
   uint_t      len;

   switch (TASK_STATE) {
      case 0:
         // clear debouce count, accumulator
         pArg->cnt = 0;
         pArg->sum = 0;
         #ifdef ENABLE_NCO
            // start nco task  //BC #ifdef ENABLE_NCO? has been defined. If it?s NOT defined then??? -it goes to case 1? 
            ncoArg.sta = 0;
            ncoArg.step = 1000;
            ncoArg.bottom = 30000;
            ncoArg.top  = 70000;
            pArg->handle = TASK_Add (NCO_Task, (void *)&ncoArg);
         #endif  //BC should this be commented out? as no "ifdef ENABLE_NCO" = would exit = nope! it activates it all! but do we need brackets? as below?
         // exit initialization
         //LED_set (LED_4Hz);  //BC add LED_set (LED_4Hz); here as a test yep it worked. Commented out again.
         TASK_STATE = 1;
         break;

      case 1:
         // wait for magnet proximity
         if (INPUT_get (0, LED_2Hz, &pArg->cnt, &pArg->sum) == false) {
            TASK_Sleep (10); //BC so check for RA! (RX) low. if it is low set LED to 2Hz and wait for timeout completion before going to 4Hz)
         }
         else {
            #ifndef ENABLE_NCO
               // output nco frequency to pin RA5, set frequency
               //RA5PPS = 0x1D;    // RA5->NCO1 BC should this be commented out??? = 
            #else
               // kill nco task
               TASK_Kill (&pArg->handle);
            #endif
            // clear accumulators  //BC reset all to = 0
            pArg->ref = 0;
            pArg->min = 0;
            pArg->max = 0;
            // set frequency
            //NCO1_Freq_set (100000);  //BC kill as NCO not needed?
            // wait 4s
            TASK_Sleep (4000);
            // next state
            TASK_STATE = 2;
         }
         break;

      case 2:
         // calibration - reference / test empty
         CAP_get (&refProbe, &tstProbe);
         // accmulate reference frequency
         pArg->ref += refProbe;
         // increment count
         pArg->cnt++;
         // check if count reached limit
         if (pArg->cnt < CAL_ITERATIONS) {
            // wait 2.2s
        LED_set (LED_4Hz);  //BC add LED_set (LED_4Hz); here as a test. Yes, no goes from 2Hz to 4Hz to indicate taking EMPTY CAL readings.
            TASK_Sleep (220);  //BC is this too long at 2200 = flashes for ages = reduce to 220 ?
            break;
         }
         else {
            // clear count
            pArg->cnt = 0;
            // set nco frequency - 70KHz (test probe calibration - empty)
            //NCO1_Freq_set (70000); //BC kill as NCO not needed?
            // wait 4s
            TASK_Sleep (4000);  //BC or is it here is this too long at 4000 = flashes for ages = reduce to 400
            // next state
            TASK_STATE = 3;
         }
         break;

      case 3:
         // calibration - test probe (empty)
         CAP_get (&refProbe, &tstProbe);
         pArg->min += tstProbe;
         // increment count
         pArg->cnt++;
         // check if count reached limit
         if (pArg->cnt < CAL_ITERATIONS) {
            // wait 2.2s
            TASK_Sleep (2200);
            break;
         }
         else {
            // clear count
            pArg->cnt = 0;
            // set led high
            LED_set (LED_2Hz) ; //BC see led.h = delay of 5000 = LED ON for 10 secs = Empty CAL Completed?? But needs to be static ie wait forever with LED on until mag goes high again?
            // next state
            TASK_STATE = 4;
         }
         break;

      case 4:
         // wait for magnet removal //BC so it should get stuck here until magnet removed?
         if (INPUT_get (1, LED_2Hz, &pArg->cnt, &pArg->sum) == false) //BC change back to LED_HI IP, try 4 Hz and input = 1
            TASK_Sleep (100);  //BC try a long sleep here 10 to 100 to 1000? yes = you are here. Back to 100 Change LED to 4Hz as a test?
         else
            TASK_STATE = 5;   //BC so it will only goto 5 
         LED_set (LED_LO); //BC LED ON continuously = YES Empty CAL Completed. Pending FULL CAL after magnet proximity test
         break;

      case 5:
         // wait for magnet proximity
         if (INPUT_get (0, LED_LO, &pArg->cnt, &pArg->sum) == false)  //BC change 2Hz to 4 to see if its coming straight here? Try LED_LO to match end of case 4 = Yes OK
            TASK_Sleep (10);
         else {
            // set nco frequency - 30Khz (test probe calibration - full)
            //NCO1_Freq_set (30000); //BC kill as NCO not needed?
            // wait 4s
            TASK_Sleep (4000);
            // next state
            TASK_STATE = 6;
         }
         break;

      case 6:
         // calibration - test probe (full)
         CAP_get (&refProbe, &tstProbe);
         pArg->max += tstProbe;
         // increment count
         pArg->cnt++;
         // check if count reached limit
         if (pArg->cnt < CAL_ITERATIONS) {
            // wait 2.2s
            LED_set (LED_4Hz);  //BC add LED_set (LED_4Hz); here as a test. Yes = "I am taking FULL CAL readings"
            TASK_Sleep (2200);
            break;
         }
         else {
            // clear (BC loop) count down on completion of CAL
            pArg->cnt = 0;
            // set led high  //BC now LO = CAL completed
         //   LED_set (LED_LO); //BC LED should go OFF = LED_LO from _HI = Yes. 
            // next state
            TASK_STATE = 7;
         }
         
      case 7:
         // update calibration values BC ie in EEPROM - CAL Successfully completed store all
         sysCfg.calRef     = pArg->ref * CAL_MULTIPLIER;
         sysCfg.calMin     = pArg->min * CAL_MULTIPLIER;
         sysCfg.calMax     = pArg->max * CAL_MULTIPLIER;
         sysCfg.spare[0]   = 0xbe;
         sysCfg.spare[1]   = 0xef;
         sysCfg.crc        = CRC_Calc (sysCfg.buf, (sizeof(SYS_CFG_t)-sizeof(crc)));
         // set start address
         pArg->addr = CFG_BASE_ADDR;
         // set source pointer
         pArg->pChar = sysCfg.buf;
         // next state
         TASK_STATE = 8;
      
      case 8:
         // write byte
         DATAEE_WriteByte (pArg->addr, *(pArg->pChar++));
         // increment address
         pArg->addr++;
         if (pArg->addr < (CFG_BASE_ADDR + sizeof(SYS_CFG_t))) 
            break;
         // console indicator - newline
         UART_Send_str ((u8 *)strCrLf, 0);
         // wait 10ms
         TASK_Sleep (10);
         // set start address
         pArg->addr = CFG_BASE_ADDR;
         // next state
         TASK_STATE = 9;
         
      case 9:
         // read configuration from nonvolatile memory
         tmp.u8 = DATAEE_ReadByte (pArg->addr);
         // print
         len = TXT_u8toAscii_Hex (tmp.u8, pArg->str);
         UART_Send (len, pArg->str);
         // increment eeprom address
         pArg->addr++;
         if (pArg->addr >= (CFG_BASE_ADDR + sizeof(SYS_CFG_t))) {
            UART_Send_str ((u8 *)strCrLf, 0);
            TASK_STATE = 10;
         }
         else {
            UART_Send_str ((u8 *)strCommaSpace, 0);
            // wait 10ms
            TASK_Sleep (10);
         }
         break;
         
      case 10:
         // wait for magnet removal
         if (INPUT_get (1, LED_2Hz, &pArg->cnt, &pArg->sum) == false)  //BC should this LED_LO be LED_2Hz ie in CAL (FULL) mode?)
            TASK_Sleep (10);
         else {
            #ifndef ENABLE_NCO
               // set pwm output pin
               RA5PPS = 0x0E;    // RA5->CCP3   BC PWM now fed to OP
            #endif
            // next state
         LED_set (LED_HI);  //BC add LED_LO to turn off ??? nope LO = ON?? LED CAL Completed  = Need LED_HI to turn OFF LED    
            TASK_STATE = 0;
         }
         break;

      default:
         done = true;
   }

   return done;
}

//-------------------------------------------------------------------------
static bool SYS_Task (void *pvArg) {
//-------------------------------------------------------------------------
   SYS_ARG_t  *pArg = (SYS_ARG_t *)pvArg;
   bool        done = false;
   
   float       m, b;             // slope, intercept //BC having CALed as above now take actual values
   uint_t      len;

   switch (TASK_STATE) {
      case 0:
         // sleep 5s
         TASK_Sleep (5000);
         // exit initialization
         TASK_STATE = 1;
         break;

      case 1:
         // clear reference, test and resistance values
         pArg->measRef.u32 = 0;
         pArg->measTst.u32 = 0;
         pArg->resOut.u32 = 0;
         // next state
         TASK_STATE = 2;
      
      case 2:
         // get reference & test probe measurements
         CAP_get (&pArg->measRef.u16, &pArg->measTst.u16);
         // apply factor to reference & test probe values to get frequency
         pArg->measRef.u32 *= CAPTURE_FACTOR;
         pArg->measTst.u32 *= CAPTURE_FACTOR;
         /*
         // validate reference reading within defined band (REF_BAND)
         if ((pArg->measRef.u32 > (sysCfg.calRef + (REF_BAND/2))) ||
             (pArg->measRef.u32 < (sysCfg.calRef - (REF_BAND/2)))) {
            // indicate reference drifted outside acceptable bounds
            UART_Send_str ((u8 *)"Check reference calibration/probe", 0);
            UART_Send_str ((u8 *)strCrLf, 0);
         } */
         // next state
         TASK_STATE = 3;
         break;

      case 3:
         if (sysCfg.calMin == sysCfg.calMax) {
            // divide-by-zero
            UART_Send_str ((u8 *)"Check reference probe", 0);
            UART_Send_str ((u8 *)strCrLf, 0);
            //  indicate error by toggling resistor output msb
            //pArg->resOut.u8 ^= (1<<7); //BC Comment out and replace with Max res and LED_4Hz? = Yes
            pArg->resOut.u8 =255;  //BC set OP to Max Res
            LED_set (LED_4Hz);  //BC set LED_4Hz to 4Hz = Error. Not activated this so far?
         }
         else if (pArg->measTst.u32 > sysCfg.calMin) {  //BC does this need some averaging to take out transients?
            // if below miniumum calibrated value, set resistance output to 0 ??? BUT this is wrong way around???
            pArg->resOut.u8 = 0;
            LED_set (LED_4Hz);  //BC add set LED_4Hz to indicate Error  = OOR (Out of Range)
         }
         else if (pArg->measTst.u32 < sysCfg.calMax) {
            // if above maximum calibrated value, set resistance output to 255
            pArg->resOut.u8 = 255;
        //    LED_set (LED_4Hz);  //BC add set LED_4Hz to indicate Error  = OOR (Out of Range)
         }
         else {
            // determine the slope-intercept values
            // m : slope
            // b : intercept
            m = 255 / (f32)(sysCfg.calMin - sysCfg.calMax);
            b = -m * (f32)(sysCfg.calMax);         
            // y = mx + b
            // y : resistance output (0 - 255)
            // determine output
            pArg->resOut.u8 = (u8)((m * pArg->measTst.u32) + b); //BC RES OP Here???? Should there be a ?m *? here?????? = added
         }
         
         // console - output level 
         UART_Send_str ((u8 *)"Level, ", 0);
         len = TXT_u8toAscii_Dec (pArg->resOut.u8, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send_str ((u8 *)strCrLf, 0);
         
         // update output resistance
         RES_set (pArg->resOut.u8);
         // sleep 2s
         TASK_Sleep (2000);
         // next state
         TASK_STATE = 2; //BC ??? was going back to Task 1 = clear data / initialise? Surely it should go back to 2 to update as now
         break;
         
      default:
         done = true;
   }

   return done;
}

//-------------------------------------------------------------------------
static void SYS_Setup (void) {
//-------------------------------------------------------------------------
   #ifdef DEBUG_PWM
      // pwm3 test task
      pwm3Arg.sta = 0;
      TASK_Add (PWM3_Test_Task, (void *)&pwm3Arg);
   #else
      // default pwm duty cycle
      PWM3_LoadDutyValue (400);
   #endif

   // frequency capture
   CAP_Init ();

   // adc
   ADC_Init();

   // resistor
   RES_Init();

   // led
   LED_Init();

   // calibration
   calArg.sta = 0;
   calTaskHandle = TASK_Add (CAL_Task, &calArg);
   
   // system task
   sysArg.sta = 0;
   TASK_Add (SYS_Task, (void *)&sysArg);
}

//-------------------------------------------------------------------------
static void RES_Init (void) {
//-------------------------------------------------------------------------
   // disable resistor output
   RES_ENA_LAT = 0;      //BC reset to = 0 to enable OP = Yes = OK
   // set to highest resistance
   RES_set(255);

   #ifdef DEBUG_RES   //BC Comment all out to disble all res test?
     // resArg.sta = 0;
     // TASK_Add (RES_Test_Task, (void *)&resArg);
   #endif
}

/*#ifdef DEBUG_RES
const u8    strRes      [] = "Resistor, ";
//-------------------------------------------------------------------------
static bool RES_Test_Task (void *pvArg) {
//-------------------------------------------------------------------------
   RES_ARG_t  *pArg = (RES_ARG_t *)pvArg;
   bool        done = false;
   uint_t      len;

   switch (TASK_STATE) {
      case 0:
         // set initial resistance value
         pArg->val = 1;
         // set starting resistance
         RES_set (pArg->val);
         // disable resistor output
         RES_ENA_LAT = 0;   //BC reset to = 0 from 1 to enable OP = Yes OK works
         // exit initialization
         TASK_STATE = 1;
         break;

      case 1:
         // output resistance update
         RES_set (pArg->val);
         // print - resistor value
         UART_Send_str ((u8 *)strRes, 0);
         len = TXT_u8toAscii_Dec (pArg->val, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send_str ((u8 *)strCrLf, 0);
         // increment value
         if (pArg->val != 255)
            pArg->val++;
         else {
            pArg->val = 254;
            TASK_STATE = 2;
         }
         // sleep 1s
         TASK_Sleep (1000);
         break;

      case 2:
         // output resistance update
         RES_set (pArg->val);
         // print - resistor value
         UART_Send_str ((u8 *)strRes, 0);
         len = TXT_u8toAscii_Dec (pArg->val, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send_str ((u8 *)strCrLf, 0);
         // increment value
         if (pArg->val != 1)
            pArg->val--;
         else {
            pArg->val = 2;
            // next state
            TASK_STATE = 1;
         }
         // sleep 1s
         TASK_Sleep (1000);
         break;

      default:
         done = true;
   }

   return done;
}
#endif   // DEBUG_RES     */

#ifdef DEBUG_PWM
//-------------------------------------------------------------------------
static bool PWM3_Test_Task (void *pvArg) {
//-------------------------------------------------------------------------
   PWM_ARG_t  *pArg = (PWM_ARG_t *)pvArg;
   bool        done = false;

   switch (TASK_STATE) {
      case 0:
         pArg->dc = 0;
         TASK_STATE = 1;
         break;

      case 1:
         pArg->dc += PWM_STEP_SIZE;       // increment duty cycle
         if (pArg->dc > 990) {            // check if max value reached
            pArg->dc = 990;
            TASK_STATE = 2;                // change direction
         }
         // load updated duty cycle, sleep 20ms
         PWM3_LoadDutyValue (pArg->dc);
         TASK_Sleep (1000);
         break;

      case 2:
         pArg->dc -= PWM_STEP_SIZE;
         if (pArg->dc < PWM_STEP_SIZE) {  // check if min value reached
            pArg->dc = PWM_STEP_SIZE;
            TASK_STATE = 1;                // change direction
         }
         // load updated duty cycle, sleep 1000ms
         PWM3_LoadDutyValue (pArg->dc);
         TASK_Sleep (1000);
         break;

      default:
         done = true;
   }

   // return task running status
   return done;
}
#endif

#ifdef ENABLE_NCO
//-------------------------------------------------------------------------
static bool NCO_Task (void *pvArg) {
//-------------------------------------------------------------------------
   NCO_ARG_t  *pArg = (NCO_ARG_t *)pvArg;
   bool        done = false;

   switch (TASK_STATE) {
      case 0:
         // set nco output pin
         RA5PPS = 0x1D;   // RA5->NCO1;
         // limit starting frequency
         if (pArg->freq < pArg->bottom || pArg->freq > pArg->top)
            pArg->freq = pArg->bottom;
         // exit initialization state
         TASK_STATE = 1;
         break;

      case 1:
         // set frequency output
         NCO1_Freq_set (pArg->freq);
         // increase frequency by step value until top reached
         pArg->freq += pArg->step;
         if (pArg->freq > pArg->top) {
            pArg->freq = pArg->top;
            TASK_STATE = 2;
         }
         // put task to sleep for 1s
         TASK_Sleep (4000);
         break;

      case 2:
         // set frequency output
         NCO1_Freq_set (pArg->freq);
         // decrease frequency by step value until bottom reached
         pArg->freq -= pArg->step;
         if (pArg->freq < pArg->bottom) {
            pArg->freq = pArg->bottom;
            TASK_STATE = 1;
         }
         // put task to sleep for 4s
         TASK_Sleep (4000);
         break;

      default:
         done = true;
   }

   // return task running status
   return done;
}
#endif   // ENABLE_NCO
#ifndef _ADC_H_
#define _ADC_H_


// inc
//-------------------------------------------------------------------------
#include "main.h"


// extern
//-------------------------------------------------------------------------
extern void ADC_Init (void);
extern void ADC_sel (uint_t ch);
extern void ADC_start (void);
extern bool ADC_get (u16 *pData);

#endif

// inc
//-------------------------------------------------------------------------
#include "mcc_generated_files/interrupt_manager.h"
#include "mcc_generated_files/pin_manager.h"
#include "mcc_generated_files/uart.h"
#include "task.h"


// param
//-------------------------------------------------------------------------
#define  TASKS_MAX         12


// type
//-------------------------------------------------------------------------

typedef bool (*TASK_FUNC_t)(void *);

typedef struct {
   TASK_FUNC_t    func;       // task function
   void          *pvArg;      // task argument
   u16            sleep;      // task sleep count
} TASK_t;


// var
//-------------------------------------------------------------------------
static bool    tmrFlag     = false;
static TASK_t *pTask       = NULL;
static TASK_t  tasks [TASKS_MAX];   // task array


// proto
//-------------------------------------------------------------------------
/*
void     TMR0_ISR (void);
void     TASK_Init (void);
uint_t   TASK_Add (TASK_FUNC_t func, void *pvArg);
void     TASK_Sleep (u16 period);
bool     TASK_Wake (uint_t handle);
void     TASK_Kill (uint_t *pHandle);
void     TASK_Scheduler (void);
*/

//-------------------------------------------------------------------------
void TMR0_ISR (void) {
//-------------------------------------------------------------------------
   PIR0bits.TMR0IF = 0;          // clear interrupt flag
   tmrFlag = true;               // set flag
}

//-------------------------------------------------------------------------
void TASK_Init (void) {
//-------------------------------------------------------------------------
   // setup hardware timer tick
   T0CON1bits.T0CS     = 2;      // Fosc/4
   T0CON1bits.T0ASYNC  = 0;      // Synchronized
   T0CON1bits.T0CKPS   = 4;      // 1:16 prescaler
   TMR0H = 0xF9;                 // reload value - 250
   TMR0L = 0x00;
   PIR0bits.TMR0IF = 0;          // clear interrupt flag 
   PIE0bits.TMR0IE = 1;          // enabling tmr0 interrupt
   T0CON0 = 0x80;                // enable tmr0
   
   // initialize task array
   for (uint_t idx = 0; idx < TASKS_MAX; idx++) {
      pTask = &tasks[idx];
      pTask->func    = NULL;
      pTask->pvArg   = NULL;
      pTask->sleep   = 0;
   }
}

//-------------------------------------------------------------------------
uint_t TASK_Add (TASK_FUNC_t func, void *pvArg) {
//-------------------------------------------------------------------------
   for (uint_t handle = 0; handle < TASKS_MAX; handle++) {
      TASK_t *pAlloc = &tasks[handle];
      if (pAlloc->func == NULL) {
         pAlloc->func   = func;        // assign task function
         pAlloc->pvArg  = pvArg;       // assign task argument
         pAlloc->sleep  = 0;           // disable sleep
         // return valid task handle
         return handle;
      }
   }
   // return invalid handle
   return TASKS_MAX;
}

//-------------------------------------------------------------------------
void TASK_Sleep (u16 period) {
//-------------------------------------------------------------------------
   // assign sleep period (1 - 65534 counts down), 65535 sleeps indefinitely
   pTask->sleep = period;
}

//-------------------------------------------------------------------------
void TASK_Kill (uint_t *pHandle) {
//-------------------------------------------------------------------------
   if (*pHandle >= TASKS_MAX)
      return;
   // select task stack, kill by clearing function pointer
   TASK_t *pAlloc = &tasks[*pHandle];
   pAlloc->func    = NULL;
   // clean handle pointer value
   *pHandle = (uint_t)(-1);
}

//-------------------------------------------------------------------------
bool TASK_Wake (uint_t handle) {
//-------------------------------------------------------------------------
   if (handle >= TASKS_MAX) return false;
   TASK_t *pAlloc = &tasks[handle];
   pAlloc->sleep  = 0;
   return true;
}

//-------------------------------------------------------------------------
void TASK_Scheduler (void) {
//-------------------------------------------------------------------------
   uint_t      idx   = (TASKS_MAX-1);
   
   // Enable the Global Interrupts
   INTERRUPT_GlobalInterruptEnable();
   // Enable the Peripheral Interrupts
   INTERRUPT_PeripheralInterruptEnable();
   
   // scheduling loop
   while (1) {
      // check tick flag
      if (tmrFlag == true) {
         tmrFlag = false;
         // decrement all task sleep counters
         for (uint_t idx = 0; idx < TASKS_MAX; idx++) {
            TASK_t *pTest = &tasks[idx];
            // skip if task function is null
            if (pTest->func == NULL) continue;
            // check if task is sleeping
            if (pTest->sleep == 0 || pTest->sleep == 65535) continue;
            // decrement sleep counter
            pTest->sleep--;
         }
      }
      
      // go to next active task
      idx = (idx+1) % TASKS_MAX;
      pTask = &tasks[idx];
      if (pTask->func == NULL) continue;
      // if task sleeping, go to next active task
      if (pTask->sleep > 0) continue;
      // execute task, return pointer value indicates if task ended
      if (pTask->func(pTask->pvArg) == false) continue;
      // remove task
      pTask->func = NULL;
   }
}

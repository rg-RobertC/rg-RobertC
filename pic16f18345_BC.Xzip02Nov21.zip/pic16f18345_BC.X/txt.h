#ifndef _TEXT_H_
#define _TEXT_H_


// inc
//-------------------------------------------------------------------------
#include "main.h"


// extern
//-------------------------------------------------------------------------
extern uint_t TXT_u8toAscii_Dec (u8 val, u8 *pStr);
extern uint_t TXT_u16toAscii_Dec (u16 val, u8 *pStr);
extern uint_t TXT_u32toAscii_Dec (u32 val, u8 *pStr);
extern uint_t TXT_u8toAscii_Hex (u8 val, u8 *pStr);
extern uint_t TXT_u16toAscii_Hex (u16 val, u8 *pStr);
extern uint_t TXT_u32toAscii_Hex (u32 val, u8 *pStr);

#endif
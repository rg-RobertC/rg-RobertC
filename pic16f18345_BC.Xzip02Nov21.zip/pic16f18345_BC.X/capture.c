// inc
//-------------------------------------------------------------------------
#include "mcc_generated_files/mcc.h"
#include "config.h"
#include "task.h"
#include "txt.h"
#include "capture.h"
#include "sys.h"


// param
//-------------------------------------------------------------------------
#define TMR1_CONFIG     0xc5
#define TMR1_RELOAD_H   0x0d        // high byte (-62000) = 2 second rollover
#define TMR1_RELOAD_L   0xcf        // low byte  (-62000) = 2 second rollover

#define CAP_BUF_SIZE    (1<<2)


// type
//-------------------------------------------------------------------------
typedef struct {
   uint_t   sta;
   u8       str      [12];
} CAP_ARG_t;


// var
//-------------------------------------------------------------------------
static volatile u16     cnt1;
static volatile u16     cnt2;

static volatile uint_t  capIdx   = 0;
static volatile uint_t  rIdx;
static volatile u16     cap1     [CAP_BUF_SIZE];
static volatile u16     cap2     [CAP_BUF_SIZE];


// proto
//-------------------------------------------------------------------------
/*
void TMR1_ISR (void);
void CCP1_ISR (void);
void CCP2_ISR (void);
void CAP_Init (void);
void CAP_get (u16 *pData1, u16 *pData2);
void CAP_TaskHandle_set (uint_t handle);
*/

//-------------------------------------------------------------------------
void TMR1_ISR (void) {
//-------------------------------------------------------------------------
   PIR1bits.TMR1IF = 0;                      // clear interrupt flag
   TMR1H = TMR1_RELOAD_H;                    // load timer high register
   TMR1L = TMR1_RELOAD_L;                    // load timer low register
                                             
   cap1[capIdx] = cnt1;                      // store capture 1
   cap2[capIdx] = cnt2;                      // store capture 2
   capIdx = (capIdx+1) & (CAP_BUF_SIZE-1);   // update index
                                 
   cnt1 = 0;                                 // clear count 1
   cnt2 = 0;                                 // clear count 2
}

//-------------------------------------------------------------------------
void CCP1_ISR (void) {
//-------------------------------------------------------------------------
   PIR4bits.CCP1IF = 0;
   cnt1++;
}

//-------------------------------------------------------------------------
void CCP2_ISR (void) {
//-------------------------------------------------------------------------
   PIR4bits.CCP2IF = 0;
   cnt2++;
}

//-------------------------------------------------------------------------
void CAP_Init (void) {
//-------------------------------------------------------------------------
   // tmr1
   T1GCON = 0x00;                // disable gating
   TMR1H = TMR1_RELOAD_H;        // load timer high register
   TMR1L = TMR1_RELOAD_L;        // load timer low register
   PIR1bits.TMR1IF = 0;          // clear interrupt flag
   PIE1bits.TMR1IE = 1;          // enable interrupt
   T1CON = TMR1_CONFIG;          // LF oscillator, enable
   
   // ccp1
   CCP1CON = 0x87;               // 16 rising edge, right-aligned, enable
   CCP1CAP = 0x00;               // output ccp1 pin
   CCPR1H = 0x00;                // clear capture register
   CCPR1L = 0x00;    
   CCPTMRSbits.C1TSEL = 0x1;     // select tmr1
   PIR4bits.CCP1IF = 0;          // clear interrupt flag
   PIE4bits.CCP1IE = 1;          // enable interrupt
   
   // ccp2
   CCP2CON = 0x87;               // 16 rising edge, right-aligned, enable
   CCP2CAP = 0x00;               // output ccp2 pin                      
   CCPR2H = 0x00;                // clear capture register               
   CCPR2L = 0x00;                                                        
   CCPTMRSbits.C2TSEL = 0x1;     // select tmr1                          
   PIR4bits.CCP2IF = 0;          // clear interrupt flag                 
   PIE4bits.CCP2IE = 1;          // enable interrupt                     
}

//-------------------------------------------------------------------------
void CAP_get (u16 *pData1, u16 *pData2) {
//-------------------------------------------------------------------------
   // determine index to read data from
   rIdx = (capIdx-1) & (CAP_BUF_SIZE-1);
   // set pointer data
   *pData1 = cap1[rIdx];
   *pData2 = cap2[rIdx];
}
/*
//-------------------------------------------------------------------------
//static bool CAP_Task (void *pvArg) {
//-------------------------------------------------------------------------
   CAP_ARG_t  *pArg  = (CAP_ARG_t *)pvArg;
   bool        done  = false;
   utyp_t      tmp;
   uint_t      len;

   switch (TASK_STATE) {
      case 0:
         // put task to sleep until interrupt wakes it up
         TASK_Sleep ((u16)(-1));
         // exit initialization
         TASK_STATE = 1;
         break;

      case 1:
         // print capture 1
         UART_Send (9, (u8 *)"Capture, ");
         // print out frequency value
         tmp.u32 = (u32)cap1;
         tmp.u32 <<= 3;
         len = TXT_u32toAscii_Dec (tmp.u32, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send (2, (u8 *)", ");
         // sleep for 10ms, allow for uart to finish sending data
         TASK_Sleep (10);
         // next state to wake up in
         TASK_STATE = 2;
         break;
         
      case 2:
         // print out frequency value
         tmp.u32 = (u32)cap2;
         tmp.u32 <<= 3;
         len = TXT_u32toAscii_Dec (tmp.u32, pArg->str);
         UART_Send (len, pArg->str);
         UART_Send (2, (u8 *)"\r\n");
         // put task to permanent sleep until interrupt
         TASK_Sleep ((u16)(-1));
         // next state to wake up in
         TASK_STATE = 1;
         break;

      default:
         done = true;
   }

   // return task running status
   return done;
} */
